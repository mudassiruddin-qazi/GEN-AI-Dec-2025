import os

import streamlit as st

S3_BUCKET_NAME = "cloudage-docker-genai"
